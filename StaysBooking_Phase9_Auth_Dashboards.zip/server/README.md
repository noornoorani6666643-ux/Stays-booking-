# StaysBooking Phase 9 Auth & role dashboards API
Install Node LTS and PostgreSQL. Run `npm install`; copy `.env.example` to `.env` and configure both secrets; then `npx prisma generate && npx prisma migrate dev --name auth_roles`; start with `npm run dev`.
Routes: POST /auth/register, POST /auth/login, GET /dashboard/guest, GET /dashboard/owner, GET /dashboard/admin, POST /owner/properties.
Role assignment is not exposed through registration; new users default to GUEST. Owner/admin roles must be assigned through a trusted administrative process.
Development scaffold only: add email verification, reset-password flow, throttling, secure production secret management, audit logging, tests, and frontend integration before launch.
